window.setTimeout(function(){
alert("Hammer Time!");},
5000);

function hammerTime(time){
    window.setTimeout(function(){
        alert(`${ time } is hammertime!`);}
     );
    }