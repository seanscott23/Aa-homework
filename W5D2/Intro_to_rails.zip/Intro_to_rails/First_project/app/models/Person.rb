class Person < ApplicationRecord
    

end
