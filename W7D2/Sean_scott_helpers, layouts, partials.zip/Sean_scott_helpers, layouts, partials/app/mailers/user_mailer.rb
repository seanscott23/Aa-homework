class UserMailer < ApplicationMailer
    def welcome_email(user)
    # your code here
  end
end
